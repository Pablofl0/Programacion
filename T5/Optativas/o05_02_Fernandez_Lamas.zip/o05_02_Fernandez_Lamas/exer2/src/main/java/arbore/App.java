package arbore;

import java.util.List;

/**
 * Hello world!
 */
public final class App {
    public static void main(String[] args) {
    }
}
