package arbore;

public class Nodo<T> {
    private Nodo<T> subIzq;
    private Nodo<T> subDer;

    
    public Nodo<T> getSubIzq() {
        return subIzq;
    }
    public Nodo<T> getSubDer() {
        return subDer;
    }


    
}
