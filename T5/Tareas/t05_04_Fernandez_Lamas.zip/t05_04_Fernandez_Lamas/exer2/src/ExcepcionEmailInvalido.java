public class ExcepcionEmailInvalido extends Exception{

    /**
     * Creamos a excepcion
     * @param mensaxe a mensaxe que se mostra
     */
    public ExcepcionEmailInvalido(String mensaxe) {
        super(mensaxe);
    }
    
}