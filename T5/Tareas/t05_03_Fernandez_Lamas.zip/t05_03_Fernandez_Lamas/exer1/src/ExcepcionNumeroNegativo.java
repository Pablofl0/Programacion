public class ExcepcionNumeroNegativo extends Exception{
    public ExcepcionNumeroNegativo(String mensaje){
        super(mensaje);
    }
}
