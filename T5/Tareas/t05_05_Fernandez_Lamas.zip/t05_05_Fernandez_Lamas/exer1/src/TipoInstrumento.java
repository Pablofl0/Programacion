public enum TipoInstrumento {
    flauta,
    saxofon,
    trombon
}
