package Excepciones;
public class ExcepcionGeneral extends Exception{
    public ExcepcionGeneral(String mensaje){
        super(mensaje);
    }
}
