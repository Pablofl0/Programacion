public enum TipoUsuario {
    Administrador,
    Cliente
}
