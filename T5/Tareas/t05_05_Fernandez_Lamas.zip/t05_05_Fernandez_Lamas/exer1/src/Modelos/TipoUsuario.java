package Modelos;
public enum TipoUsuario {
    Administrador,
    Cliente
}
