package Modelos;
public enum TipoSaxo {
    soprano,
    alto,
    tenor,
    baritono
}
