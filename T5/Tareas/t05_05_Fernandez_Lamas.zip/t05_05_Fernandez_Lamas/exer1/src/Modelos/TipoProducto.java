package Modelos;
public enum TipoProducto {
    flauta,
    saxofon,
    trombon,
    libro,
    estuche
}
