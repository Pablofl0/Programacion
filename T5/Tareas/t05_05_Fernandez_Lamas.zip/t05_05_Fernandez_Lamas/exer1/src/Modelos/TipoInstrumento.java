package Modelos;
public enum TipoInstrumento {
    flauta,
    saxofon,
    trombon
}
