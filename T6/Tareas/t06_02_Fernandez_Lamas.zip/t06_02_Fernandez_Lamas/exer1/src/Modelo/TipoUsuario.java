package Modelo;

import java.io.Serializable;

public enum TipoUsuario implements Serializable {
    ADMINGENERAL,
    ADMINBIBLIOTECA,
    CLIENTE
}
