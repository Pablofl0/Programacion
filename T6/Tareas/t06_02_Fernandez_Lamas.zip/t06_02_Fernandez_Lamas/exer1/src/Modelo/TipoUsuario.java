package Modelo;
public enum TipoUsuario {
    ADMINGENERAL,
    ADMINBIBLIOTECA,
    CLIENTE
}
