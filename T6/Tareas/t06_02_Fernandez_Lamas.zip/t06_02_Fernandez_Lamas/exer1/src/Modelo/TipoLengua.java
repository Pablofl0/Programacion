package Modelo;

import java.io.Serializable;

public enum TipoLengua implements Serializable {
    GALLEGO,
    CASTELLANO,
    INGLÉS
}
