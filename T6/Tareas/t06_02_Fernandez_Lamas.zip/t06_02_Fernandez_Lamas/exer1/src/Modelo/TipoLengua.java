package Modelo;
public enum TipoLengua {
    GALLEGO,
    CASTELLANO,
    INGLÉS
}
