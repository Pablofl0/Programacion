package Excepciones;

public class ExcepcionEjemplaresInsuficientes extends Exception{
    public ExcepcionEjemplaresInsuficientes(){
        super("No hay suficientes ejemplares.");
    } 
}
