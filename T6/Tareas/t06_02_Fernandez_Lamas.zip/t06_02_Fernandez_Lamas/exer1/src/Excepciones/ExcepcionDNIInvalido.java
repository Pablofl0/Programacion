package Excepciones;

public class ExcepcionDNIInvalido extends Exception{
    public ExcepcionDNIInvalido(){
        super("El DNI no es válido.");
    } 
}
