package Excepciones;

public class ExcepcionIdNoValido extends Exception{
    public ExcepcionIdNoValido(){
        super("El identificador no es válido.");
    }
}
