package Excepciones;

public class ExcepcionEmailInvalido extends Exception{


    public ExcepcionEmailInvalido(String mensaxe) {
        super(mensaxe);
    }
    
}