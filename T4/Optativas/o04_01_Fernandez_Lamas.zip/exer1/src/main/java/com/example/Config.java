package com.example;

public class Config {
    private String lenguaSeleccionada;

    public Config() {
        this.lenguaSeleccionada = "gal";
    }

    public String getLenguaSeleccionada() {
        return lenguaSeleccionada;
    }

    public void setLenguaSeleccionada(String lenguaSeleccionada) {
        this.lenguaSeleccionada = lenguaSeleccionada;
    }
}
