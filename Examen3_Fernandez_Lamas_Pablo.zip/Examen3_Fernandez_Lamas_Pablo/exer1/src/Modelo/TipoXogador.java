package Modelo;

import java.io.Serializable;

public enum TipoXogador implements Serializable {
    BASE,
    EXTERIOR,
    INTERIOR
}
