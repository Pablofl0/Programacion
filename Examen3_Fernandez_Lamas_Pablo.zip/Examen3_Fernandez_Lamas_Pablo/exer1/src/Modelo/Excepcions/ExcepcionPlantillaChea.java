package Modelo.Excepcions;

public class ExcepcionPlantillaChea extends Exception {
    public ExcepcionPlantillaChea() {
        super("La plantilla está llena.");
    }
}
