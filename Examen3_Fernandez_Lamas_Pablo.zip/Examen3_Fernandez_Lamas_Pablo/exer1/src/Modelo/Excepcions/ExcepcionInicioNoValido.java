package Modelo.Excepcions;
public class ExcepcionInicioNoValido extends Exception{
    public ExcepcionInicioNoValido(){
        super("Inicio de sesión no válido.");
    }
}
