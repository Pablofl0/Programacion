package Modelo.Excepcions;

public class ExcepcionCidadeNoValida extends Exception {
    public ExcepcionCidadeNoValida() {
        super("Ciudad no válida.");
    }
}
