package Modelo;

import java.io.Serializable;

public enum Provincia implements Serializable {
    LUGO,
    CORUÑA,
    PONTEVEDRA,
    OURENSE
}
