package Modelo;

import java.io.Serializable;

public enum TipoUsuario implements Serializable{
    ADMINISTRADOR,
    EQUIPO,
    XOGADOR
}
