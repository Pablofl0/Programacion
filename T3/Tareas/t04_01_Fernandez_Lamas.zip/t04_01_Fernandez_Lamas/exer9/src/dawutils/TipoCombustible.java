package dawutils;

public enum TipoCombustible {
    DIÉSEL,
    GASOLINA,
    ELÉCTRICO
}
